# ChatGPT Session Notes

## Overview

ChatGPT was used as a support tool during development, mainly for debugging issues, validating approaches, and improving certain parts of the backend logic.

---

## Where it helped

### Backend Debugging

* Faced issues with Node.js module system (ESM vs CommonJS)
* Used ChatGPT to understand the error and fix import/require usage

### Routing Issues

* Initially placed the wildcard route (`*`) incorrectly, which blocked API routes
* Took help to identify correct route order and fix it

### Express Version Issue

* Encountered error with wildcard routes in Express v5
* Used ChatGPT to understand why it was happening and applied a compatible solution

### Deployment Decisions

* Explored multiple deployment approaches
* Finalized serving frontend from backend to avoid CORS and simplify setup

### General Validation

* Used ChatGPT occasionally to validate logic and ensure best practices (e.g., folder structure, API handling)

---

## My Approach

* Core backend logic, API design, and database integration were implemented manually
* ChatGPT was mainly used when stuck or to speed up debugging
* Iteratively refined the system based on errors and testing

---

## Outcome

* Stable backend with working APIs
* Clean integration between frontend and backend
* No runtime or deployment issues after fixes
